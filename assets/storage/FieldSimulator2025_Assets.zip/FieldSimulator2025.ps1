Add-Type -AssemblyName 'System.Windows.Forms'
Add-Type -AssemblyName 'System.Drawing'

$modernFont = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)

function Set-WheatButtonStyle($button) {
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.BackColor = [System.Drawing.Color]::FromArgb(225, 200, 150)
    $button.ForeColor = [System.Drawing.Color]::White
    $button.Font = $modernFont
    $button.FlatAppearance.BorderSize = 0
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
}

[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.BackgroundImage = [System.Drawing.Image]::FromFile("%USERPPROFILE%\Documents\FieldSimulator2025\assets\background.jpg")
$form.BackgroundImageLayout = "Center"
$form.Text = "Field Simulator 2025"
$form.AutoSize = $true
$form.AutoSizeMode = 'GrowAndShrink'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(400, 400)

$balance = 100

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Size = New-Object System.Drawing.Size(350, 20)
$statusLabel.Location = New-Object System.Drawing.Point(20, 20)
$statusLabel.Text = "Welcome to the farm!"
$statuslabel.BackColor = [System.Drawing.Color]::Transparent
$form.Controls.Add($statusLabel)

$startButton = New-Object System.Windows.Forms.Button
Set-WheatButtonStyle $startButton
$startButton.Size = New-Object System.Drawing.Size(100, 40)
$startButton.Location = New-Object System.Drawing.Point(150, 50)
$startButton.Text = "Start Game"
$startButton.Add_Click({
    $statusLabel.Text = "Loading..."
    Start-Sleep -Seconds 1
    ShowFarmMenu
})
$form.Controls.Add($startButton)

$balanceButton = New-Object System.Windows.Forms.Button
Set-WheatButtonStyle $balanceButton
$balanceButton.Size = New-Object System.Drawing.Size(100, 40)
$balanceButton.Location = New-Object System.Drawing.Point(250, 50)
$balanceButton.Text = "Balance"
$balanceButton.Add_Click({
    $statusLabel.Text = "Balance: $balance."
})
$form.Controls.Add($balanceButton)

function ShowFarmMenu {
    $statusLabel.Text = "You are going to cultivate Field 1. Select tractor."
    ShowTractorSelection
}


function ShowTractorSelection {
    HideButtons

    $claasButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $claasButton
    $claasButton.Size = New-Object System.Drawing.Size(100, 40)
    $claasButton.Location = New-Object System.Drawing.Point(50, 50)
    $claasButton.Text = "Claas AXION 800"
    $claasButton.Add_Click({
        $statusLabel.Text = "Select cultivator."
        ShowCultivatorSelection
    })
    $form.Controls.Add($claasButton)

    $deutzButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $deutzButton
    $deutzButton.Size = New-Object System.Drawing.Size(100, 40)
    $deutzButton.Location = New-Object System.Drawing.Point(200, 50)
    $deutzButton.Text = "Deutz-Fahr Series 6 TTV"
    $deutzButton.Add_Click({
        $statusLabel.Text = "Select cultivator."
        ShowCultivatorSelection
    })
    $form.Controls.Add($deutzButton)
}

function ShowCultivatorSelection {
    HideButtons

    $horschButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $horschButton
    $horschButton.Size = New-Object System.Drawing.Size(100, 40)
    $horschButton.Location = New-Object System.Drawing.Point(50, 50)
    $horschButton.Text = "Horsch Terrano 3.5FX"
    $horschButton.Add_Click({
        $statusLabel.Text = "You are ready to cultivate the field!"
        ShowFieldJobSelection
    })
    $form.Controls.Add($horschButton)

    $rabeButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $rabeButton
    $rabeButton.Size = New-Object System.Drawing.Size(100, 40)
    $rabeButton.Location = New-Object System.Drawing.Point(200, 50)
    $rabeButton.Text = "Rabe EG 3/9"
    $rabeButton.Add_Click({
        $statusLabel.Text = "You are ready to cultivate the field!"
        ShowFieldJobSelection
    })
    $form.Controls.Add($rabeButton)
}

function ShowFieldJobSelection {
    HideButtons

    $cultivateButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $cultivateButton
    $cultivateButton.Size = New-Object System.Drawing.Size(100, 40)
    $cultivateButton.Location = New-Object System.Drawing.Point(50, 50)
    $cultivateButton.Text = "Cultivate!"
    $cultivateButton.Add_Click({
        $statusLabel.Text = "Cultivating Field 1..."
        Start-Sleep -Seconds 5
        $statusLabel.Text = "Field Cultivated."
        ShowSowMenu
    })
    $form.Controls.Add($cultivateButton)

    $goBackButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $goBackButton
    $goBackButton.Size = New-Object System.Drawing.Size(100, 40)
    $goBackButton.Location = New-Object System.Drawing.Point(200, 50)
    $goBackButton.Text = "Go Back"
    $goBackButton.Add_Click({
        ShowFarmMenu
    })
    $form.Controls.Add($goBackButton)
}

function ShowSowMenu {
    HideButtons

    $sowButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $sowButton
    $sowButton.Size = New-Object System.Drawing.Size(100, 40)
    $sowButton.Location = New-Object System.Drawing.Point(50, 50)
    $sowButton.Text = "Sow Field 1"
    $sowButton.Add_Click({
        ShowSowField1
    })
    $form.Controls.Add($sowButton)

    $balanceButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $balanceButton
    $balanceButton.Size = New-Object System.Drawing.Size(100, 40)
    $balanceButton.Location = New-Object System.Drawing.Point(200, 50)
    $balanceButton.Text = "Show Balance"
    $balanceButton.Add_Click({
        $statusLabel.Text = "Balance: $balance."
        ShowSowMenu
    })
    $form.Controls.Add($balanceButton)

    $exitButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $exitButton
    $exitButton.Size = New-Object System.Drawing.Size(100, 40)
    $exitButton.Location = New-Object System.Drawing.Point(125, 100)
    $exitButton.Text = "Exit"
    $exitButton.Add_Click({
        ExitGame
    })
    $form.Controls.Add($exitButton)
}

function ShowSowField1 {
    HideButtons

    $claasButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $claasButton
    $claasButton.Size = New-Object System.Drawing.Size(100, 40)
    $claasButton.Location = New-Object System.Drawing.Point(50, 50)
    $claasButton.Text = "Claas AXION 800"
    $claasButton.Add_Click({
        $statusLabel.Text = "Select seeder"
        ShowSeederSelection
    })
    $form.Controls.Add($claasButton)

    $deutzButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $deutzButton
    $deutzButton.Size = New-Object System.Drawing.Size(100, 40)
    $deutzButton.Location = New-Object System.Drawing.Point(200, 50)
    $deutzButton.Text = "Deutz-Fahr Series 6 TTV"
    $deutzButton.Add_Click({
        $statusLabel.Text = "Select seeder"
        ShowSeederSelection
    })
    $form.Controls.Add($deutzButton)
}

function ShowSeederSelection {
    HideButtons

    $horschButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $horschButton
    $horschButton.Size = New-Object System.Drawing.Size(100, 40)
    $horschButton.Location = New-Object System.Drawing.Point(50, 50)
    $horschButton.Text = "Horsch Pronto 3 DC"
    $horschButton.Add_Click({
        $statusLabel.Text = "You are ready to sow the field!"
        ShowFieldSown
    })
    $form.Controls.Add($horschButton)

    $nordstenButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $nordstenButton
    $nordstenButton.Size = New-Object System.Drawing.Size(100, 40)
    $nordstenButton.Location = New-Object System.Drawing.Point(200, 50)
    $nordstenButton.Text = "Nordsten NS 3003"
    $nordstenButton.Add_Click({
        $statusLabel.Text = "You are ready to sow the field!"
        ShowFieldSown
    })
    $form.Controls.Add($nordstenButton)
}

function ShowFieldSown {
    $statusLabel.Text = "Sowing Field 1..."
    Start-Sleep -Seconds 5
    $statusLabel.Text = "Field sown."
    ShowFieldGrowth
}

function ShowFieldGrowth {
    $statusLabel.Text = "Field sown."
    Start-Sleep -Seconds 8
    ShowFieldHarvest
}

function ShowFieldHarvest {
    HideButtons

    $harvestButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $harvestButton
    $harvestButton.Size = New-Object System.Drawing.Size(100, 40)
    $harvestButton.Location = New-Object System.Drawing.Point(50, 50)
    $harvestButton.Text = "Harvest Field"
    $harvestButton.Add_Click({
        HarvestField
    })
    $form.Controls.Add($harvestButton)

    $exitButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $exitButton
    $exitButton.Size = New-Object System.Drawing.Size(100, 40)
    $exitButton.Location = New-Object System.Drawing.Point(200, 50)
    $exitButton.Text = "Exit"
    $exitButton.Add_Click({
        ExitGame
    })
    $form.Controls.Add($exitButton)
}

function HarvestField {
    $statusLabel.Text = "Harvesting Field..."
    Start-Sleep -Seconds 7
    $statusLabel.Text = "Field harvested"
    Start-Sleep -Seconds 2
    $statusLabel.Text = "Selling crops..."
    Start-Sleep -Seconds 5
    $statusLabel.Text = "Crops were sold. You earned 1000!"
    $balance += 1000
    ShowEndOfDay
}


function ShowEndOfDay {
    HideButtons

    $sleepButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $sleepButton
    $sleepButton.Size = New-Object System.Drawing.Size(100, 40)
    $sleepButton.Location = New-Object System.Drawing.Point(50, 50)
    $sleepButton.Text = "Sleep until morning"
    $sleepButton.Add_Click({
        $statusLabel.Text = "Sleeping..."
        Start-Sleep -Seconds 5
        ShowFarmMenu
    })
    $form.Controls.Add($sleepButton)

    $exitButton = New-Object System.Windows.Forms.Button
    Set-WheatButtonStyle $exitButton
    $exitButton.Size = New-Object System.Drawing.Size(100, 40)
    $exitButton.Location = New-Object System.Drawing.Point(200, 50)
    $exitButton.Text = "Exit"
    $exitButton.Add_Click({
        ExitGame
    })
    $form.Controls.Add($exitButton)
}

function ExitGame {
    $statusLabel.Text = "Exiting..."
    $form.Close()
}

function HideButtons {
    $form.Controls.Clear()

    $form.Controls.Add($statusLabel)
}

$form.ShowDialog()